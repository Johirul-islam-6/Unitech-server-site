export type IGenericErrorMassage = {
  path: string | number;
  message: string;
};
