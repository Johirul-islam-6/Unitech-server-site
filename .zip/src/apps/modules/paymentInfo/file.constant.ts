export const SearchableFields = [
  'SName',
  'SRoll',
  'SPhone',
  'SEmail',
  'PAdmin',
  'CDate',
  'SCetagory',
];
