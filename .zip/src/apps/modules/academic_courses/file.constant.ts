export const eventSearchableFields = [
  'CName',
  'CPrice',
  'CCode',
  'CCategory',
  'CBatch',
  'email',
];
