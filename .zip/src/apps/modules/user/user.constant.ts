export const userSearchableFields = [
  'name',
  'studentRoll',
  'ruler',
  'gender',
  'blodGroup',
  'phone',
  'institute',
  'department',
  'address',
  'email',
  'joinginDate',
];
